// ========================================================================
// KONFIGURASI SIAKAD MADRASAH — MODE MYSQL HOSTING
// ========================================================================
// Ubah DB_HOST, DB_NAME, DB_USER, DB_PASS di api.php sesuai hosting Anda
// ========================================================================

window.__ENV_USE_MYSQL__ = true;
window.__ENV_MYSQL_API_URL__ = "/api.php";

// Supabase Cloud (opsional, biarkan kosong jika pakai MySQL saja)
window.__ENV_SUPABASE_URL__ = "";
window.__ENV_SUPABASE_ANON_KEY__ = "";
